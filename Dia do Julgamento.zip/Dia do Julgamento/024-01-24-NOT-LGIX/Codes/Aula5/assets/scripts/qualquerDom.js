//alert('oi')

function dizerOla (){
    alert("Olá, Mundo!")  
}
function contar2(){
    let contador = 0
    contador ++
    document.getElementById('cont').innerHTML = contador
    console.log (contador)
}
function contador (){
    let contador = Number(document.getElementById('cont').innerHTML)
    contador ++
    document.getElementById('cont').innerHTML = contador
    console.log (contador)
}
function zerarContador(){
    let contador = document.getElementById('cont')
    contador.innerHTML = Number(contador.innerHTML) * 10
}
function inserirTexto(){
    let texto = prompt ("Digite um texto: ")
    document.getElementById('texto').value = texto
}
//dizerOla ()