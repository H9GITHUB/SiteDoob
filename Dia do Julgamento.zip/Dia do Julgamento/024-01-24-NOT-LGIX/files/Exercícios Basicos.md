# Exercícios Basicos: 

1. Imprima "Hello World!" no console:

2. Crie uma variável e atribua a ela um número qualquer. Em seguida, multiplique esse número por 2 e imprima o resultado no console:

3. Crie um script que calcule a média de três números:

4. Criar uma variável e atribuir um valor a ela:

5. Criar uma variável e realizar uma operação matemática:

6. Criar uma string e concatenar com outra:

7. Criar uma variável e exibir seu tipo:

8. Criar uma variável e exibir seu valor convertido para numero:

9. Utilizar a função prompt para obter uma entrada do usuário:

10. Utilizar a função confirm para obter uma confirmação do usuário:

11. Converter Temperatura de Fahrenheit (F) para Celsius (C) - C=5/9*(F-32)

12. Faça um algoritmo que some dois números:

13. Faça um algoritmo que subtraia dois números:

14. Faça um algoritmo que multiplique dois números:

15. Faça um algoritmo que dívida dois números:

16. Faça um algoritmo que leia dois números  e os multiplique: 

17. Faça um algoritmo que leia dois números e os dívida;

18. Elaborar um algoritmo que calcule a área de um quadrado e de o resultado:

19. Elaborar um algoritmo que entre com 4 notas de um aluno e de a média:

20. Leia 5 números:

	20.1. Efetuar a adição do primeiro com o terceiro:
	
	20.2. Efetuar a subtração do segundo com o quarto;
	
	20.3 Efetuar a multiplicação entre todos:
	
	20.4 Efetuar a divisão do quinto com o primeiro:
	
	20.5 Apresente os resultados
	
21.  Entrar com o dia e o mês de uma data e informar quantos dias se passaram desde o início do ano. Esqueça a questão dos anos bissextos e considere sempre que um mês possui 30 dias.

22.  A lanchonete Gostosura vende apenas um tipo de sanduíche, cujo recheio inclui duas fatias de queijo, uma fatia de presunto e uma rodela de hambúrguer. Sabendo que cada fatia de queijo ou presunto pesa 50 gramas, e que a rodela de hambúrguer pesa 100 gramas, faça um algoritmo em que o dono forneça a quantidade de sanduíches a fazer, e a máquina informe as quantidades (em quilos) de queijo, presunto e carne necessários para compra.
23.  A fábrica de refrigerantes Meia-Cola vende seu produto em três formatos: lata de 350 ml, garrafa de 600 ml e garrafa de 2 litros. Se um comerciante compra uma determinada quantidade de cada formato, faça um algoritmo para calcular quantos litros de refrigerante ele comprou.
24.  Desenvolva um programa que pergunte ao usuário quantos amigos ele convidou para uma festa. Peça a cada amigo para informar quantas latas de 350 ml e garrafas de 600 ml ele trouxe. Calcule e exiba a quantidade total de litros de refrigerante na festa.
25.  Faça um programa que entre com três números, faça a média aritmética e mostre o resultado.
26.  Faça um programa que entre com o nome e o salário de um funcionário e mostre seu novo salário, sabendo que o mesmo teve um aumento de 10%.
27.  Faça um programa para converter um certo valor em dólar para reais (ver cotação do dia).
28.   Faça um programa que leia um saldo e imprimir o saldo com reajuste de 1%.
29.   Faça um programa que leia o valor de um produto e imprimir o valor corrigido com o reajuste de 33.33%.
30.  Faça um programa que leia o salário de um funcionário e o percentual de aumento, calcule e mostre o valor do aumento e o novo salário.
31.  Escreva um programa que apresente uma caixa de alerta para o usuário com uma informação qualquer.
32.  Escreva um algoritmo para ler um valor (do teclado) e escrever (na tela) o seu antecessor. 
33.  Escreva um algoritmo para ler as dimensões de um retângulo (base e altura), calcular e escrever a área do retângulo. 
34.  Faça um algoritmo que leia a idade de uma pessoa expressa em anos, meses e dias e escreva a idade dessa pessoa expressa apenas em dias. Considerar ano com 365 dias e mês com 30 dias. 
35.   Escreva um algoritmo para ler o número total de eleitores de um município, o número de votos brancos, nulos e válidos. Calcular e escrever o percentual que cada um representa em relação ao total de eleitores. 
36.   Escreva um algoritmo para ler o salário mensal atual de um funcionário e o percentual de reajuste. Calcular e escrever o valor do novo salário.
37.   O custo de um carro novo ao consumidor é a soma do custo de fábrica com a porcentagem do distribuidor e dos impostos (aplicados ao custo de fábrica). Supondo que o percentual do distribuidor seja de 28% e os impostos de 45%, escrever um algoritmo para ler o custo de fábrica de um carro, calcular e escrever o custo final ao consumidor. 
38.   Uma revendedora de carros usados paga a seus funcionários vendedores um salário fixo por mês, mais uma comissão também fixa para cada carro vendido e mais 5% do valor das vendas por ele efetuadas. Escrever um algoritmo que leia o número de carros por ele vendidos, o valor total de suas vendas, o salário fixo e o valor que ele recebe por carro vendido. Calcule e escreva o salário final do vendedor. 
39.   Fazer um programa que pergunta um valor em metros e imprime o correspondente em decímetros, centímetros e milímetros.
40.   Fazer um programa que imprima a média aritmética dos números 8,9 e 7. A média dos números 4, 5 e 6. A soma das duas médias. A média das médias.
 




> Esses são exercícios bem simples usando lógica com Javascript, tente resolvelos
> com calma... sem pressa ... você tem bastante tempo.
> Caso não consiga, não chore, não se desespere, você já está vários degraus acima 
> de quem nem tentou! Pode me pedir ajuda ... estou sempre a disposição !
> Caso consiga resolver, Parabêns!!!!!!! E não se esqueca que proxima aula tem mais ...
